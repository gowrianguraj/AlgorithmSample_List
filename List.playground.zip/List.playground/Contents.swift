import UIKit

class Node<T> : CustomStringConvertible {
    var value : T
    var next : Node?

    init(value : T , next : Node? = nil) {
    self.value = value
    self.next = next
}
var description : String {
    guard let next = next else {
        return "\(value)"
       
    }
    return "/(value)->" + String(describing: next) + ""
    }
 }
let node1 = Node(value :4)
let node2 = Node(value :8)
let node3 = Node(value :10)

node1.next = node2
node2.next = node3

print(node1)


// Reverse a String
let str = "Gowri"
String(str.characters.reversed())

//Another way
let str1 = "Shan"
let reversedWord = String(str1.reversed())
print(reversedWord)

//Palindrome String
func isPalindrome(myString:String) -> Bool {
    let reverseString = String(myString.characters.reversed())
    if(myString != "" && myString == reverseString) {
        return true
    } else {
        return false
    }
}

print(isPalindrome(myString: "madam"))

//Remove duplicates string

func removeDuplicatesFrom2(_ input: String) -> String {
    var usedCharacters = [Character]()
    
    for letter in input.characters {
        if !usedCharacters.contains(letter) {
            usedCharacters.append(letter)
        }
    }
    
    return String(usedCharacters)
}

print(removeDuplicatesFrom2("Hello world"))

//Find Last element
extension Node {
    public var last : T {
        return next?.last ?? value
    }
}
//Find the last but one before
extension Node {
    public var lastBefore : T? {
        guard let nextvalue = next else {
            return nil
        }
        return nextvalue.lastBefore ?? value
    }
}
//Find the Middle number in the linked list
extension Node {
    public subscript(index: Int) -> T? {
        return index == 0 ? value : next?[index-1]
    }
}
//Find number of elements
extension Node {
    public var lenght : Int {
        return 1 + (next?.lenght ?? 0)
    }
}
// Reverse the linked list
extension Node {
    //P05 (*) Reverse a linked list.
    // Note: Original list is considered immutable and remains the same after the reverse() call.
    public func reverse() -> Node {
        var immutableHead = self
        var current = Node(value: value)
        while immutableHead.next != nil {
            immutableHead = immutableHead.next!
            let newHead = Node(value: immutableHead.value)
            newHead.next = current
            current = newHead
        }
        return current
    }
}

